package pack

import org.apache.spark._

object objTest {

    def main (args : Array[String]): Unit ={
      println("Hello world")
    }

}

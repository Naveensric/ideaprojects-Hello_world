package pack

object objFram {

  def main (args:Array[String]): Unit={
    println("naveen");
  }

}
